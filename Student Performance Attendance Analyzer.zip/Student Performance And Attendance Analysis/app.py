# ==================================================
# IMPORT FLASK
# ==================================================

# Flask is used to create our website
from flask import Flask

# Used to open HTML page
from flask import render_template

# Used to get data from HTML form
from flask import request

# Used to move to another page
from flask import redirect

# Used to find a page
from flask import url_for

# Used to show chart files
from flask import send_file
from flask import jsonify


# ==================================================
# IMPORT PYTHON MODULES
# ==================================================

# Used to work with CSV files
import csv

# Used to work with folders and files
import os
import math

# Used for data analysis
import pandas as pd

# Used for numerical calculation
import numpy as np

# Used for making graphs
import matplotlib

# This helps Matplotlib work with Flask
matplotlib.use("Agg")

# Used to create graphs
import matplotlib.pyplot as plt


# ==================================================
# CREATE FLASK APP
# ==================================================

app = Flask(__name__)


# ==================================================
# FILE AND FOLDER NAMES
# ==================================================

# Use the folder containing app.py as the project folder.
# This prevents files from being saved in a different working directory.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Folder for data files and graphs
data_folder = os.path.join(BASE_DIR, "data")
chart_folder = os.path.join(BASE_DIR, "charts")

# Absolute file paths
csv_file = os.path.join(data_folder, "students.csv")
text_file = os.path.join(data_folder, "students.txt")


# ==================================================
# CREATE FOLDERS
# ==================================================

# Create required folders beside app.py.
os.makedirs(data_folder, exist_ok=True)
os.makedirs(chart_folder, exist_ok=True)


# ==================================================
# CREATE CSV FILE
# ==================================================

def create_csv_file():

    # Create the CSV file with a header only when it is missing or empty.
    if not os.path.exists(csv_file) or os.path.getsize(csv_file) == 0:
        with open(csv_file, "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow([
                "Roll",
                "Name",
                "Python",
                "C Programming",
                "DBMS",
                "Web Development",
                "Attendance"
            ])


# Create CSV file
create_csv_file()


# ==================================================
# CALCULATE TOTAL
# ==================================================

def calculate_total(marks):

    # Start total from zero
    total = 0

    # Take one mark at a time
    for mark in marks:

        # Add mark to total
        total = total + mark

    # Return total
    return total


# ==================================================
# CALCULATE AVERAGE
# ==================================================

def calculate_average(marks):

    # Calculate total
    total = calculate_total(marks)

    # Calculate average
    average = total / len(marks)

    # Keep two decimal places
    average = round(average, 2)

    # Return average
    return average


# ==================================================
# CALCULATE PERCENTAGE
# ==================================================

def calculate_percentage(marks):

    # Calculate total marks
    total = calculate_total(marks)

    # Four subjects have total 400 marks
    percentage = (total / 400) * 100

    # Keep two decimal places
    percentage = round(percentage, 2)

    # Return percentage
    return percentage


# ==================================================
# CALCULATE GRADE
# ==================================================

def calculate_grade(percentage):

    # Check percentage
    if percentage >= 90:

        grade = "A+"

    elif percentage >= 80:

        grade = "A"

    elif percentage >= 70:

        grade = "B"

    elif percentage >= 60:

        grade = "C"

    elif percentage >= 50:

        grade = "D"

    else:

        grade = "F"

    # Return grade
    return grade


# ==================================================
# READ STUDENTS
# ==================================================

def read_students():

    # Make sure the CSV file exists.
    create_csv_file()

    with open(csv_file, "r", newline="", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)
        return list(reader)


# ==================================================
# SAVE STUDENT IN CSV
# ==================================================

def save_student(student):

    # Append one student record to the project's CSV file.
    with open(csv_file, "a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([
            student["roll"],
            student["name"],
            student["python"],
            student["c"],
            student["dbms"],
            student["web"],
            student["attendance"]
        ])


# ==================================================
# SAVE ALL STUDENTS IN CSV
# ==================================================

def save_all_students(students):

    # Rewrite the CSV file with the header and all current student records.
    with open(csv_file, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow([
            "Roll",
            "Name",
            "Python",
            "C Programming",
            "DBMS",
            "Web Development",
            "Attendance"
        ])

        for student in students:
            writer.writerow([
                student["Roll"],
                student["Name"],
                student["Python"],
                student["C Programming"],
                student["DBMS"],
                student["Web Development"],
                student["Attendance"]
            ])


# ==================================================
# SAVE TEXT FILE
# ==================================================

def save_text_file():

    # Keep the text file synchronized with the CSV records.
    students = read_students()

    with open(text_file, "w", encoding="utf-8") as file:
        for student in students:
            file.write(
                "Roll: " + student["Roll"] +
                ", Name: " + student["Name"] +
                ", Python: " + student["Python"] +
                ", C: " + student["C Programming"] +
                ", DBMS: " + student["DBMS"] +
                ", Web: " + student["Web Development"] +
                ", Attendance: " + student["Attendance"] + "\n"
            )


# ==================================================
# PREPARE STUDENT DATA
# ==================================================

def prepare_students():

    # Read students from CSV
    old_students = read_students()

    # Empty list
    students = []

    # Take one student at a time
    for student in old_students:

        # Get Python marks
        python_mark = int(
            student["Python"]
        )

        # Get C marks
        c_mark = int(
            student["C Programming"]
        )

        # Get DBMS marks
        dbms_mark = int(
            student["DBMS"]
        )

        # Get Web marks
        web_mark = int(
            student["Web Development"]
        )

        # Put marks in a list
        marks = [
            python_mark,
            c_mark,
            dbms_mark,
            web_mark
        ]

        # Calculate total
        total = calculate_total(marks)

        # Calculate average
        average = calculate_average(marks)

        # Calculate percentage
        percentage = calculate_percentage(marks)

        # Calculate grade
        grade = calculate_grade(percentage)

        # Get attendance
        attendance = float(
            student["Attendance"]
        )

        # Create new student dictionary
        new_student = {

            "roll": student["Roll"],

            "name": student["Name"],

            "python": python_mark,

            "c": c_mark,

            "dbms": dbms_mark,

            "web": web_mark,

            "total": total,

            "average": average,

            "percentage": percentage,

            "grade": grade,

            "attendance": attendance
        }

        # Add student
        students.append(new_student)

    # Return students
    return students


# ==================================================
# HOME PAGE
# ==================================================

@app.route("/")
def home():

    # Get all students
    students = prepare_students()

    # Count students
    total_students = len(students)

    # Empty low attendance list
    low_attendance = []

    # Check attendance
    for student in students:

        if student["attendance"] < 75:

            low_attendance.append(student)

    # Start class average
    class_average = 0

    # Check if students exist
    if len(students) > 0:

        total_percentage = 0

        # Add all percentages
        for student in students:

            total_percentage = (
                total_percentage
                + student["percentage"]
            )

        # Calculate class average
        class_average = (
            total_percentage
            / len(students)
        )

        class_average = round(
            class_average,
            2
        )

    # Open HTML page
    return render_template(
        "index.html",
        students=students,
        total_students=total_students,
        low_attendance=low_attendance,
        class_average=class_average,
        message="",
        error="",
        edit_student=None
    )


# ==================================================
# VALIDATION HELPERS
# ==================================================

def validate_student_values(roll, name, marks, attendance):
    if not roll or not name:
        raise ValueError("Please enter both roll number and student name.")

    if len(roll) > 30:
        raise ValueError("Roll number must not exceed 30 characters.")

    if len(name) > 100:
        raise ValueError("Student name must not exceed 100 characters.")

    # Allow alphabetic characters and spaces only.
    if not name.replace(" ", "").isalpha():
        raise ValueError("Student name must contain alphabetic characters only (spaces are allowed).")

    for mark in marks:
        if mark < 0 or mark > 100:
            raise ValueError("Marks must be between 0 and 100.")

    if not math.isfinite(attendance) or attendance < 0 or attendance > 100:
        raise ValueError("Attendance must be a valid number between 0 and 100.")


# ==================================================
# ADD STUDENT
# ==================================================

@app.route(
    "/add-student",
    methods=["POST"]
)
def add_student():

    try:

        # Get roll number
        roll = request.form.get("roll", "").strip()

        # Get student name
        name = request.form.get("name", "").strip()

        # Get Python marks
        python_mark = int(
            request.form.get("python", "")
        )

        # Get C marks
        c_mark = int(
            request.form.get("c", "")
        )

        # Get DBMS marks
        dbms_mark = int(
            request.form.get("dbms", "")
        )

        # Get Web marks
        web_mark = int(
            request.form.get("web", "")
        )

        # Get attendance
        attendance = float(
            request.form.get("attendance", "")
        )

        # Validate all submitted values
        marks = [
            python_mark,
            c_mark,
            dbms_mark,
            web_mark
        ]
        validate_student_values(roll, name, marks, attendance)

        # Read old students
        old_students = read_students()

        # Check duplicate roll
        for student in old_students:

            if student["Roll"] == roll:

                raise ValueError(
                    "This roll number already exists."
                )

        # Create student
        student = {

            "roll": roll,

            "name": name,

            "python": str(python_mark),

            "c": str(c_mark),

            "dbms": str(dbms_mark),

            "web": str(web_mark),

            "attendance": str(attendance)
        }

        # Save student
        save_student(student)

        # Update text file
        save_text_file()

        # Go home
        return redirect(
            url_for("home")
        )

    except ValueError as error:

        # Get students
        students = prepare_students()

        # Show page with error
        return render_template(
            "index.html",
            students=students,
            total_students=len(students),
            low_attendance=[],
            class_average=0,
            message="",
            error=str(error),
            edit_student=None
        )


# ==================================================
# EDIT STUDENT PAGE
# ==================================================

@app.route("/edit/<roll>")
def edit_student(roll):

    # Read all students
    students = read_students()

    # Empty variable
    selected_student = None

    # Find student
    for student in students:

        if student["Roll"] == roll:

            selected_student = student

    # If student was not found
    if selected_student is None:

        return redirect(
            url_for("home")
        )

    # Prepare student data
    prepared_students = prepare_students()

    # Low attendance list
    low_attendance = []

    for student in prepared_students:

        if student["attendance"] < 75:

            low_attendance.append(student)

    # Calculate average
    class_average = 0

    if len(prepared_students) > 0:

        total_percentage = 0

        for student in prepared_students:

            total_percentage = (
                total_percentage
                + student["percentage"]
            )

        class_average = (
            total_percentage
            / len(prepared_students)
        )

        class_average = round(
            class_average,
            2
        )

    # Open page
    return render_template(
        "index.html",
        students=prepared_students,
        total_students=len(prepared_students),
        low_attendance=low_attendance,
        class_average=class_average,
        message="",
        error="",
        edit_student=selected_student
    )


# ==================================================
# UPDATE STUDENT
# ==================================================

@app.route(
    "/update-student/<old_roll>",
    methods=["POST"]
)
def update_student(old_roll):

    try:

        # Get new roll number
        roll = request.form.get("roll", "").strip()

        # Get student name
        name = request.form.get("name", "").strip()

        # Get marks
        python_mark = int(
            request.form.get("python", "")
        )

        c_mark = int(
            request.form.get("c", "")
        )

        dbms_mark = int(
            request.form.get("dbms", "")
        )

        web_mark = int(
            request.form.get("web", "")
        )

        # Get attendance
        attendance = float(
            request.form.get("attendance", "")
        )

        # Validate all submitted values
        marks = [
            python_mark,
            c_mark,
            dbms_mark,
            web_mark
        ]
        validate_student_values(roll, name, marks, attendance)

        # Read students
        students = read_students()

        # Check roll number
        for student in students:

            # Do not compare with old student
            if student["Roll"] != old_roll:

                if student["Roll"] == roll:

                    raise ValueError(
                        "This roll number already exists."
                    )

        # Find and update student
        for student in students:

            if student["Roll"] == old_roll:

                student["Roll"] = roll

                student["Name"] = name

                student["Python"] = str(
                    python_mark
                )

                student["C Programming"] = str(
                    c_mark
                )

                student["DBMS"] = str(
                    dbms_mark
                )

                student["Web Development"] = str(
                    web_mark
                )

                student["Attendance"] = str(
                    attendance
                )

        # Save updated data
        save_all_students(students)

        # Update text file
        save_text_file()

        # Go back home
        return redirect(
            url_for("home")
        )

    except ValueError as error:

        # Get students
        students = prepare_students()

        # Show error
        return render_template(
            "index.html",
            students=students,
            total_students=len(students),
            low_attendance=[],
            class_average=0,
            message="",
            error=str(error),
            edit_student=None
        )


# ==================================================
# DELETE STUDENT
# ==================================================

@app.route("/delete/<roll>")
def delete_student(roll):

    # Read all students
    students = read_students()

    # Create empty list
    new_students = []

    # Check every student
    for student in students:

        # Keep every student except selected student
        if student["Roll"] != roll:

            new_students.append(student)

    # Save remaining students to CSV.
    save_all_students(new_students)

    # Synchronize the text file with the updated CSV file.
    save_text_file()

    # Go back home
    return redirect(
        url_for("home")
    )


# ==================================================
# SORT STUDENTS
# ==================================================

@app.route("/sort")
def sort_students():

    # Get students
    students = prepare_students()

    # Sort using simple loop
    for i in range(len(students)):

        for j in range(i + 1, len(students)):

            if students[i]["total"] < students[j]["total"]:

                # Temporary student
                temp = students[i]

                # Change position
                students[i] = students[j]

                students[j] = temp

    # Low attendance list
    low_attendance = []

    for student in students:

        if student["attendance"] < 75:

            low_attendance.append(student)

    # Start average
    class_average = 0

    if len(students) > 0:

        total_percentage = 0

        for student in students:

            total_percentage = (
                total_percentage
                + student["percentage"]
            )

        class_average = (
            total_percentage
            / len(students)
        )

        class_average = round(
            class_average,
            2
        )

    # Show sorted page
    return render_template(
        "index.html",
        students=students,
        total_students=len(students),
        low_attendance=low_attendance,
        class_average=class_average,
        message="Students sorted by total marks.",
        error="",
        edit_student=None
    )


# ==================================================
# SEARCH STUDENT
# ==================================================

@app.route("/search")
def search_student():

    # Get search word
    keyword = request.args.get(
        "keyword",
        ""
    )

    # Convert to small letters
    keyword = keyword.lower()

    # Get students
    students = prepare_students()

    # Empty search result
    search_results = []

    # Search every student
    for student in students:

        # Student name
        name = student["name"].lower()

        # Student roll
        roll = student["roll"].lower()

        # Check name or roll
        if keyword in name or keyword in roll:

            search_results.append(student)

    # Low attendance list
    low_attendance = []

    for student in search_results:

        if student["attendance"] < 75:

            low_attendance.append(student)

    # Start average
    class_average = 0

    if len(search_results) > 0:

        total_percentage = 0

        for student in search_results:

            total_percentage = (
                total_percentage
                + student["percentage"]
            )

        class_average = (
            total_percentage
            / len(search_results)
        )

        class_average = round(
            class_average,
            2
        )

    # Show result
    return render_template(
        "index.html",
        students=search_results,
        total_students=len(search_results),
        low_attendance=low_attendance,
        class_average=class_average,
        message=("Search complete: " + str(len(search_results)) + " matching student record(s) found.")
                if len(search_results) > 0 else "",
        error=("Invalid student or student not found. Please check the name or roll number.")
              if len(search_results) == 0 else "",
        edit_student=None
    )


# ==================================================
# PANDAS ANALYSIS
# ==================================================

@app.route("/pandas-analysis")
def pandas_analysis():

    # Get students
    students = prepare_students()

    # If no students
    if len(students) == 0:

        return redirect(
            url_for("home")
        )

    # Empty data list
    data = []

    # Take one student
    for student in students:

        # Create data
        one_student = {

            "Name": student["name"],

            "Total": student["total"],

            "Average": student["average"],

            "Percentage": student["percentage"],

            "Attendance": student["attendance"]
        }

        # Add data
        data.append(one_student)

    # Create DataFrame
    df = pd.DataFrame(data)

    # Highest marks
    highest_marks = df["Total"].max()

    # Lowest marks
    lowest_marks = df["Total"].min()

    # Average marks
    average_marks = df["Total"].mean()

    average_marks = round(
        average_marks,
        2
    )

    # Average attendance
    average_attendance = df["Attendance"].mean()

    average_attendance = round(
        average_attendance,
        2
    )

    # Create message
    message = (
        "Highest Total: "
        + str(highest_marks)
        + " | Lowest Total: "
        + str(lowest_marks)
        + " | Average Total: "
        + str(average_marks)
        + " | Average Attendance: "
        + str(average_attendance)
        + "%"
    )

    # Low attendance list
    low_attendance = []

    for student in students:

        if student["attendance"] < 75:

            low_attendance.append(student)

    # Average percentage
    percentage_average = df["Percentage"].mean()

    percentage_average = round(
        percentage_average,
        2
    )

    # Return structured data for the asynchronous Analysis button.
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return jsonify({
            "highest_total": int(highest_marks),
            "lowest_total": int(lowest_marks),
            "average_total": average_marks,
            "average_attendance": average_attendance,
            "average_percentage": percentage_average,
            "student_count": len(students)
        })

    # Show analysis
    return render_template(
        "index.html",
        students=students,
        total_students=len(students),
        low_attendance=low_attendance,
        class_average=percentage_average,
        message=message,
        error="",
        edit_student=None
    )


# ==================================================
# BAR CHART
# ==================================================

@app.route("/bar-chart")
def bar_chart():

    # Get students
    students = prepare_students()

    # Check students
    if len(students) == 0:

        return redirect(
            url_for("home")
        )

    # Empty lists
    names = []
    totals = []

    # Get student data
    for student in students:

        names.append(
            student["name"]
        )

        totals.append(
            student["total"]
        )

    # Create graph
    plt.figure()

    # Make bar chart
    plt.bar(
        names,
        totals
    )

    # X axis
    plt.xlabel("Students")

    # Y axis
    plt.ylabel("Total Marks")

    # Title
    plt.title("Student Total Marks")

    # Rotate names
    plt.xticks(
        rotation=30
    )

    # Adjust graph
    plt.tight_layout()

    # Chart path
    os.makedirs(os.path.join(app.root_path, chart_folder), exist_ok=True)

    chart_path = os.path.join(app.root_path, chart_folder, "bar_chart.png")

    # Save chart
    plt.savefig(chart_path)

    # Close graph
    plt.close()

    # Show chart
    return send_file(
        chart_path,
        mimetype="image/png"
    )


# ==================================================
# LINE GRAPH
# ==================================================

@app.route("/line-graph")
def line_graph():

    # Get students
    students = prepare_students()

    # Check students
    if len(students) == 0:

        return redirect(
            url_for("home")
        )

    # Empty lists
    names = []
    percentages = []

    # Get student data
    for student in students:

        names.append(
            student["name"]
        )

        percentages.append(
            student["percentage"]
        )

    # Create graph
    plt.figure()

    # Make line graph
    plt.plot(
        names,
        percentages,
        marker="o"
    )

    # X axis
    plt.xlabel("Students")

    # Y axis
    plt.ylabel("Percentage")

    # Title
    plt.title("Student Performance")

    # Rotate names
    plt.xticks(
        rotation=30
    )

    # Adjust graph
    plt.tight_layout()

    # Save graph
    os.makedirs(os.path.join(app.root_path, chart_folder), exist_ok=True)

    chart_path = os.path.join(app.root_path, chart_folder, "line_graph.png")

    plt.savefig(chart_path)

    plt.close()

    # Show graph
    return send_file(
        chart_path,
        mimetype="image/png"
    )


# ==================================================
# HISTOGRAM
# ==================================================

@app.route("/histogram")
def histogram():

    # Get students
    students = prepare_students()

    # Empty percentage list
    percentages = []

    # Get percentages
    for student in students:
        percentages.append(student["percentage"])

    # Create graph
    plt.figure()

    # Create histogram only when records are available.
    if percentages:
        plt.hist(percentages, bins=5)
    else:
        plt.text(0.5, 0.5, "No student data available",
                 horizontalalignment="center",
                 verticalalignment="center",
                 transform=plt.gca().transAxes)
        plt.xlim(0, 100)
        plt.ylim(0, 1)

    # X axis
    plt.xlabel("Percentage")

    # Y axis
    plt.ylabel("Number of Students")

    # Title
    plt.title("Percentage Distribution")

    # Adjust graph
    plt.tight_layout()

    # Save histogram
    os.makedirs(os.path.join(app.root_path, chart_folder), exist_ok=True)

    chart_path = os.path.join(app.root_path, chart_folder, "histogram.png")

    plt.savefig(chart_path)

    plt.close()

    # Show histogram
    return send_file(
        chart_path,
        mimetype="image/png"
    )


# ==================================================
# START PROGRAM
# ==================================================

if __name__ == "__main__":

    # Start Flask server
    app.run(
        debug=True
    )